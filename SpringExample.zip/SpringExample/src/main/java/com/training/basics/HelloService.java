package com.training.basics;

public interface HelloService {
public String sayHello();
public String sayHello(String name,String city);
}
