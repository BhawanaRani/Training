package com.training.Hello18n;

public interface Greeting {
public String greetHello();
}
