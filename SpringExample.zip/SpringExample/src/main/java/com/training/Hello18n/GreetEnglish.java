package com.training.Hello18n;

public class GreetEnglish implements Greeting{

	
	public String greetHello()
	{
		return "Hello World";
	}
}
