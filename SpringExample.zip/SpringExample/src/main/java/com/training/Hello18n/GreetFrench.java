package com.training.Hello18n;

public class GreetFrench implements Greeting{
	public String greetHello()
	{
		return "Bonjour tout le mode ";
	}
}
