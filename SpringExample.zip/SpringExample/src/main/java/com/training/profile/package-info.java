/**
 * 
 */
/**
 * @author bhawana.r
 *provide the profile in spring with annotations
 */
package com.training.profile;