/**
 * 
 */
/**
 * @author bhawana.r
 * 
 * 
 * program is use to show the working of message in spring
 *
 */
package com.training.messageResource;